import java.util.*;

class LinearSearch1{
public static void linearSearch(int[] arr,int i,int item){
if(i>=arr.length){return;}
if(i<arr.length){
	if(arr[i]==item){
	System.out.println(" element " +item+ "  fount at index " +i);
	return;
	}
	else{
	linearSearch(arr,i+1,item);
	}

}
}
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
System.out.println("enter the size of the array");
int n=sc.nextInt();
int[] arr=new int[n];
for(int i=0;i<arr.length;i++){
arr[i]=sc.nextInt();
}
System.out.println(" eneter the element you wanto search");
int item=sc.nextInt();
linearSearch(arr,0,item);
}
}