import java.util.*;
class MergeSort{
public static void merge(int[] arr,int lb,int mid,int ub){
int[] merged=new int[ub-lb+1];
int indx1=lb;
int indx2=mid+1;
int x=0;
while(indx1<=mid && indx2<=ub){
if(arr[indx1]<arr[indx2]){
merged[x]=arr[indx1];
indx1++;
x++;
}
else{
merged[x]=arr[indx2];
indx2++;
x++;}

}
while(indx1<=mid){
merged[x]=arr[indx1];
indx1++;
x++;

}
while(indx2<=ub){
merged[x]=arr[indx2];
indx2++;
x++;}

for(int i=0,j=lb;i<merged.length;i++,j++){
arr[j]=merged[i];

}

}


public static void divided(int[] arr,int lb,int ub){
if(lb>=ub){
return;
}

int mid=(lb+ub)/2;
divided(arr,lb,mid);
divided(arr,mid+1,ub);
merge(arr,lb,mid,ub);



}

public static void main(String[] args){
Scanner sc=new Scanner(System.in);
System.out.println(" enter the size of the array");
int n=sc.nextInt();
int[] arr=new int[n];
System.out.println("enter the elements int the array");
for(int i=0; i<arr.length;i++){
arr[i]=sc.nextInt();

}
divided(arr,0,arr.length-1);
for(int i=0; i<arr.length;i++){
System.out.println(arr[i]);
}



}


}