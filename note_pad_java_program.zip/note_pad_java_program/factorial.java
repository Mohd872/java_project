import java.util.*;

class Fact{
public static int fact(int n){
if(n==0){
return 1;}
int factorial=n*fact(n-1);
return factorial;

}
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println("enter the value of n");
int n=sc.nextInt();
int a=fact(n);
System.out.println(a);
	

}

}