import java.util.*;

class QuickSort{
public static int partition(int[] arr,int si,int ei){
int pivot=arr[(si+ei)/2];
int temp;
while(si<ei){
while(arr[si]<pivot){
si++;
}
while(arr[ei]>pivot){
ei--;

}

temp=arr[si];
arr[si]=arr[ei];
arr[ei]=temp;




}
return si;

}
static void print(int[] arr){
for(int e:arr){
System.out.println(e);

}

}


public static  void quickSort(int[] arr,int si,int ei){
if(si>=ei){
return;
}
int loc=partition(arr, si,ei);
quickSort(arr,si,loc-1);
quickSort(arr,loc+1,ei);

}
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println("enter the size of the array");
int n=sc.nextInt();
int[] arr=new int[n];
System.out.println("enter the elements in the array");
for(int i=0;i<arr.length;i++){
arr[i]=sc.nextInt();

}
quickSort(arr,0,arr.length-1);
System.out.println("sorted array id ");
print(arr);






}

}