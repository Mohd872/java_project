import java.util.*;
class HeapPractise{
public static void print(int[] arr){
for(int e:arr){
System.out.pritnln(e);

}
 public static void heapify(int[] arr,int length,int i){
largest=i;
left=2*i+1;
right=2*i+2;
if(left<length && arr[left]>arr[largest]){
largest=left;
}
if(right<length && arr[right]>arr[largest]){
largest=right;
}

if(largest!=i){
int temp=arr[largest];
arr[largest]=arr[i];
arr[i]=temp;
heapify(arr,length,largest);


}


}
public static void heapsort(int[] arr){
int length=arr.length;
for(int i=length/2-1;i>=0;i--){

heapify(arr,length,i);}



for(int i=length-1;i>=0;i--){
int temp=arr[0];
arr[0]=arr[i];
arr[i]=temp;
heapify(arr,i,0);


}
}




public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println("enter the size of the array");
int n=sc.nextInt();
int[] arr=new int[n];
System.out.println("enter the elements in the array");
for(int i=0;i<arr.length;i++){
arr[i]=sc.nextInt();

}
heapsort(arr);
System.out.println("sorted array is ");
print(arr);


}
}
