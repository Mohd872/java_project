import java.applet.Applet;
import java.awt.*;

class  A extends Applet {
    public void paint(Graphics g){
        g.drawString("salauddin",100,100);
}}
    