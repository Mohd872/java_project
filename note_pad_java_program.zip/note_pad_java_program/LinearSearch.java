import java.util.*;
class LinearSearch
{
 public static void main(String arg[])
 {
   int temp=0;
  Scanner sc = new Scanner(System.in);
 System.out.println("size of array");
  int n =sc.nextInt();
  System.out.println("item");
  int item= sc.nextInt();
  int arr[] = new int[n];
 System.out.println("elements of array");
  for(int i=0; i<arr.length; i++)
    {
     arr[i] = sc.nextInt();
    }
   for(int i=0; i<arr.length; i++)
     {
      if(arr[i]==item)
       {
	temp=1;
	}
      }
   if (temp==0)
    {
    System.out.println("item not found");
   }
   else
    {
    System.out.println("item found");
   }
 }
}