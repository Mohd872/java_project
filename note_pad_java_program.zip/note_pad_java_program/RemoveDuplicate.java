package spring1.spring_setting;

public class RemoveDuplicate {
    public static void main(String[] args) {
        int[] arr={1,3,2,4,5,2};
        int[] k=new int[arr.length-1];
        int count=0;
        for (int i=0;i<arr.length;i++){
            for (int j=i+1;j<arr.length;j++){
                if (arr[i]==arr[j]){

                    count=j;
                }
            }
        }
        for (int i=0;i<k.length;i++){
            if (i==count ){
                continue;
            }
            else {
                k[i]=arr[i];
                System.out.println(k[i]);
            }
        }
    }
}
