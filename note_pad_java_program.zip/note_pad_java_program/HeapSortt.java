import java.util.*;

class HeapSortt{

public static void print(int[] arr){
	for(int e:arr){

	System.out.println(e);
}

}
public static void heapify(int[] arr,int length,int i){
int largest=i;
int leftchild=2*i+1;
int rightchild=2*i+2;
if(leftchild<length && arr[leftchild]>arr[largest]){
	largest=leftchild;
}
if(rightchild<length && arr[rightchild]>arr[largest]){
	largest=rightchild;
}
if(largest!=i){
	int temp=arr[i];
	arr[i]=arr[largest];
	arr[largest]=temp;
	heapify(arr,length,largest);


}

}
public static void sort(int[] arr){
int length=arr.length;
for(int i=length/2-1;i>=0;i--){
	heapify(arr,length,i);
}
for(int i=length-1;i>=0;i--){
	int temp=arr[0];
	arr[0]=arr[i];
	arr[i]=temp;
	heapify(arr,i,0);

}
}

public static void main(String[] args){
Scanner scanner = new Scanner(System.in);
        System.out.println("enter the size of the array");
        int n = scanner.nextInt();
        int[] arr=new int[n];
        System.out.println("enter the elements in the arrray one by one");
        for (int i=0;i< arr.length;i++){
            arr[i]=scanner.nextInt();
            
        }
sort(arr);
System.out.println(" sorted array is ");
print(arr);



}

}