import java.util*;
 
public class Oneloopsorting{

public static void main(string[] args){

int[] arr={3,1,6,2,3,9,7,0};
for(int i=1;i<arr.length;i++){
	if(arr[i]<arr[i-1])
	{
	int temp=arr[i];
	arr[i]=arr[i+1];
	arr[i+1]=temp;
	i=0;
	}



}

for(int k=0;k<arr.length;k++){

	System.out.println(arr[k]);
}


}

}