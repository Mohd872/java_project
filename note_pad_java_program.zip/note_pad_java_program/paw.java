import java.util.*;

class Pow{
public static int power(int x,int y){
if(y==0){
return 1;}
int a=power(x,y-1);
int b=x*a;
return b;

}
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println("enter the value of x");
int x=sc.nextInt();
System.out.println("enter the value of y");
int y=sc.nextInt();
int c=power(x,y);
System.out.println(c);
	

}

}