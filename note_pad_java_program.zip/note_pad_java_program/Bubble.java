import java.util.*;
class BubbleSort{
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println(" enter the size of the array");
int n=sc.nextInt();
int[] a=new int[n];
System.out.println("enter the elements in the array");
for(int i=0;i<a.length;i++){
a[i]=sc.nextInt();
}
int temp;
for(int i=0;i<a.length;i++){
for(int j=0;j<a.length-1;j++){
if(a[j+1]<a[j]){
temp=a[j];
a[j]=a[j+1];
a[j+1]=temp;


}

}

}
for(int k=0;k<a.length;k++){
System.out.println(a[k]);
}

}

}