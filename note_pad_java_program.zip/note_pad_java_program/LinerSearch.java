class LinearSearch
{
 public Static void main(String arg[])
 {
   int temp=0;
  Scanner sc = new Scanner(System.in);
 System.out.println("size of array");
  int n =sc.nextInt();
  System.out.println("item");
  int item= sc.nextItem();
 System.out.println("elements of array");
  for(int i=0; i<arr.length; i++)
    {
     arr[i] = sc.nextInt();
    }
   for(int i=0; i<arr.lenght; i++)
     {
      if(arr[i]==item)
       {
	temp=1;
	}
      }
   if (temp==0;)
    {
    System.out.println("item not found");
   }
   else (temp==1;)
    {
    System.out.println("item found");
   }
 }
}