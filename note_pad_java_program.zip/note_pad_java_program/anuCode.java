import java.io.*;
import java.util.*;
class printNumber{

public static void main(String [] args){
	
 int[] a1={1,2,2,5,5,2,5,6,7,4,3};
        int[] a2=new int[a1.length];
        for (int i=0;i<a1.length;i++){
            a2[a1[i]]=a2[a2[i]+1];
            
        }
        for (int i=0;i<a1.length;i++){
            System.out.println(a2[i]);
        }
    

}
	
  
	

}