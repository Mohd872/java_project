import java.util.*;

public class MinHeap {
    public static void MinHeap(int[] arr,int length,int i){
        int smallest=i;
        int left=2*i+1;
        int right=2*i+2;
        if (left<length && arr[left]<arr[smallest]){
            smallest=left;
        }
        if (right<length && arr[right]<arr[smallest]){
            smallest=right;
        }
        if (smallest!=i){
            int temp=arr[i];
            arr[i]=arr[smallest];
            arr[smallest]=temp;
		MinHeap(arr,length,smallest);
        }
    }

    public static void sort(int[] arr){
        int length=arr.length;
        for (int i=length/2-1;i>=0;i--){
            MinHeap(arr,length,i);
        }
        for (int i=length-1;i>=0;i--){
            int temp=arr[0];
            arr[0]=arr[i];
            arr[i]=temp;
            MinHeap(arr,i,0);
        }
    }
    public static void print(int[] arr){
        for (int e:arr) {
            System.out.println(e);

        }
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the size of the array");
        int n = scanner.nextInt();
        int[] arr=new int[n];
        System.out.println("enter the elements in the arrray one by one");
        for (int i=0;i< arr.length;i++){
            arr[i]=scanner.nextInt();
            
        }
	sort(arr);
	System.out.println("sorted array is");
	print(arr);
    }
}
