import java.util.*;
class BinarySearch{
public static void binarySearch(int[] arr,int si,int ei,int item){
if(si>=ei){
if(arr[si]==item){
System.out.println(si);
}else{
System.out.println("-1");
}
return;
}

int mid=(si+ei)/2;
if(arr[mid]==item){
System.out.println("element fount at mid"+mid);
return;
}
if(item<arr[mid]){
binarySearch(arr,si,mid-1,item);
}
else{
binarySearch(arr,mid+1,ei,item);
}

}
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
System.out.println("enter the size of the array");
int n = sc.nextInt();
int[] arr=new int[n];
System.out.println(" enter the elements in the array");
for(int i=0;i<arr.length;i++){
arr[i]=sc.nextInt();
}
System.out.println(" enter the element you want to find");
int item=sc.nextInt();

binarySearch(arr,0,arr.length-1,item);
}

}