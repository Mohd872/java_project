import java.util.*;

class InsertionSort{
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
System.out.println("enter the size of the array");
int n=sc.nextInt();
int[] a=new int[n];
System.out.println("enter the elements in the array");
for(int i=0;i<a.length;i++){
a[i]=sc.nextInt();
}
int temp;
int j;
for(int i=1;i<a.length;i++){
temp=a[i];
j=i-1;
while(j>=0 && a[j]>temp){
a[j+1]=a[j];
j--;


}
a[j+1]=temp;

}
System.out.println(" sorted element in the array");
for(int k=0;k<a.length;k++){
	System.out.println(a[k]);

}



}

}